from common import *
from ui.dialogs import UIDialogMixin
from ui.main_window import MainWindowMixin
from core.image_manager import ImageManagerMixin
from core.annotation import AnnotationMixin
from core.calibration import CalibrationMixin
from core.project_io import ProjectIOMixin
from core.excel_export import ExcelExportMixin
from core.image_export import ImageExportMixin
from core.pdf_export import PDFExportMixin
from core.densitometry import DensitometryMixin


class EasyGelAlyzerApp(
    UIDialogMixin,
    MainWindowMixin,
    ImageManagerMixin,
    AnnotationMixin,
    CalibrationMixin,
    ProjectIOMixin,
    ExcelExportMixin,
    ImageExportMixin,
    PDFExportMixin,
    DensitometryMixin,
):
    def __init__(self, root):
        self.root = root
        # メインウィンドウを画面中央に配置
        self.root.update_idletasks()
        win_w = 1280
        win_h = 1024
        x = (self.root.winfo_screenwidth() - win_w) // 2
        y = (self.root.winfo_screenheight() - win_h) // 2
        self.root.geometry(f"{win_w}x{win_h}+{x}+{y}")


        # ---- アイコン設定 ----
        _here = os.path.dirname(os.path.abspath(__file__))
        _icon_dirs = (_here, os.path.join(_here, 'assets'))
        for _icon_name in ("icon.ico", "icon.png", "icon.jpg", "icon.jpeg"):
            _icon_path = next((os.path.join(_d, _icon_name) for _d in _icon_dirs if os.path.exists(os.path.join(_d, _icon_name))), None)
            if _icon_path:
                try:
                    if _icon_name.endswith(".ico"):
                        self.root.iconbitmap(_icon_path)
                    else:
                        _icon_img = ImageTk.PhotoImage(Image.open(_icon_path))
                        self.root.iconphoto(True, _icon_img)
                        self._icon_img = _icon_img  # GC防止
                except Exception:
                    LOGGER.exception("Unexpected error")
                break

        self.mode = None

        self.source_image = None
        self.original_image = None
        self.processed_image = None

        self.zoom_scale = 1.0
        self.pan_x = 0
        self.pan_y = 0

        self.start_line_y = None
        self.end_line_y = None
        self.start_line_id = 'start_line'
        self.end_line_id = 'end_line'

        # マーカー: [{'id', 'name', 'y', 'size', 'rf'}]
        self.markers = []
        # 試料: [{'id', 'name', 'x', 'y', 'rf', 'size', 'color'}]
        # x, y はクリックした元画像座標（点として保存）
        self.samples = []

        self.calibration_a = 0.0
        self.calibration_b = 0.0
        self.calibration_r2 = 0.0

        self.marker_visible = True
        self.grayscale = False          # 白黒モード（プレビュー・出力共通）
        self._annot_bw_white = True        # 白黒時の注釈線色デフォルト=白

        self.undo_stack = []
        self.redo_stack = []

        # モード: 'none','set_start','set_end','add_marker','add_sample','drag_start','drag_end',
        #         'drag_marker','drag_sample','trim_drag'
        self.active_mode = 'none'
        self.drag_target = None

        self.trim_start_x = None
        self.trim_start_y = None
        self.trim_end_x = None
        self.trim_end_y = None
        self.trim_rect_id = None

        self.rotation_angle = 0.0
        self.rotation_confirmed = True
        self._rotation_sliding = False

        # 手動回帰係数が適用されているか
        self._manual_coeff_applied = False

        self.brightness_val = 0
        self.contrast_val = 0
        self.bg_corr_radius = None

        # サンプルカラー: マーカー色(#FF9F00)・開始ライン色(#007AFF)・終了ライン色(#FF3B30)と被らない色
        self.color_palette = ['#34C759', '#AF52DE', '#A2561F', '#00C7BE', '#5856D6', '#FF6B9D', '#00B894', '#6C5CE7']

        # 泳動ラインラベル: [{'id', 'type': 'marker'|'sample', 'name', 'x', 'y_above_start'}]
        # x: 横位置(元画像系), y_above_start: 開始ラインより上に表示(固定値, キャンバスオフセット)
        self.lane_labels = []
        self.lane_label_font_size = 11  # ラベルフォントサイズ（スライダーで変更可）
        self.densitometry_rois = []
        self._dens_roi_start = None
        self._dens_roi_rect_id = None
        self.image_preset_mode = 'none'

        # アイテムごとの表示/非表示 (id -> bool)
        self.item_visibility = {}
        self.item_export_visibility = {}

        # 中ボタンダブルクリック判定用
        self._last_middle_click_time = 0.0
        self._tree_drag_anchor = None
        self._tree_rows_cache = None
        self._tree_drag_last_row = None
        self._tree_drag_last_selection = ()
        self._drag_redraw_after_id = None
        self._native_dnd_proc = None
        self._native_dnd_original_wndproc = None

        # 言語設定
        set_language(get_config().get('language', 'en'))

        # Shiftキーダブルプレス判定用
        self._last_shift_press_time = 0.0

        # トラックパッド2本指パン用
        self._trackpad_pan_x = 0
        self._trackpad_pan_y = 0

        self.show_mode_selection_dialog()

        # --- バージョン表示ラベル（ステータスバー） ---
        version_label = ttk.Label(self.root, text=f"EasyGelAlyzer v{VERSION}", anchor="e")
        version_label.pack(fill=tk.X, side=tk.BOTTOM)

        self.create_widgets()

        # ウィンドウ初期配置時にペイン比率を1:2:1にする
        self.root.update_idletasks()
        try:
            total_w = self.main_pane.winfo_width()
            if total_w > 10:
                self.main_pane.sashpos(0, int(total_w * 0.25))
                self.main_pane.sashpos(1, int(total_w * 0.75))
                if hasattr(self, '_adjust_main_pane_layout'):
                    self._adjust_main_pane_layout()
        except Exception:
            LOGGER.exception("Unexpected error")
        
        self.setup_bindings()
        self.update_window_title()
        self.root.protocol("WM_DELETE_WINDOW", self.on_app_close)
        # Drag & drop must be initialized after the window handle is available
        self.root.after(100, self._init_dnd)
        if getattr(self, "_load_project_on_startup", False):
            self.root.after(150, self.load_project)

    # ------------------------------------------------------------------ #
    #  モード選択ダイアログ
    # ------------------------------------------------------------------ #
    def update_window_title(self):
        self.root.title(T('title_protein') if self.mode == "protein" else T('title_dna'))

    def on_app_close(self):
        """アプリを閉じる時の確認ダイアログを表示"""
        if self.original_image is not None and self._has_unsaved_changes():
            res = self.show_yesnocancel_dialog(
                T('confirm_quit_title'),
                T('confirm_quit_msg')
            )
            if res is True:
                # はい：保存済みプロジェクトは上書き保存、未保存なら名前を付けて保存する。
                save_ok = self.save_project_quick() if getattr(self, "project_path", None) else self.save_project()
                if save_ok:
                    self.root.destroy()
            elif res is False:
                # いいえ：保存せずに終了
                self.root.destroy()
            else:
                # キャンセル、またはダイアログを閉じた：何もしない
                pass
        else:
            self.root.destroy()

    # ------------------------------------------------------------------ #
    #  ウィジェット構築
    # ------------------------------------------------------------------ #

